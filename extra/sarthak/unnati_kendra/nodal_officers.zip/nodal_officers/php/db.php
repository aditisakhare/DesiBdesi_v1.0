<?php 
   $conn = mysqli_connect('localhost', 'root', 'root' ,'unnati_kendra');
?>